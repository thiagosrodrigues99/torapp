# 📖 AWF User Guide - Hướng dẫn sử dụng cho người mới

> **AWF (Antigravity Workflow Framework)** giúp bạn làm app mà không cần biết code.
> Bạn chỉ cần nói ý tưởng, AI sẽ lo phần còn lại.

---

## 🎯 AWF dùng để làm gì?

| Bạn muốn... | AWF giúp bạn... |
|-------------|-----------------|
| Làm app mới | Từ ý tưởng → App hoàn chỉnh |
| Thêm tính năng | Thiết kế → Code → Test tự động |
| Sửa lỗi | Tìm lỗi → Sửa → Kiểm tra |
| Deploy lên server | Cấu hình → Đẩy lên → Theo dõi |

---

## 🗺️ Bản đồ các lệnh AWF

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           AWF WORKFLOW MAP                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ╔═══════════════════════════════════════════════════════════════════════╗  │
│  ║                    🌟 KHỞI ĐẦU & TÌM HIỂU                             ║  │
│  ╠═══════════════════════════════════════════════════════════════════════╣  │
│  ║  /brainstorm  │  /init      │  /recap       │  /next                  ║  │
│  ║  Bàn ý tưởng  │  Tạo mới    │  Nhớ lại      │  Bước tiếp              ║  │
│  ╚═══════════════════════════════════════════════════════════════════════╝  │
│                              │                                              │
│                              ▼                                              │
│  ╔═══════════════════════════════════════════════════════════════════════╗  │
│  ║                    🎯 THIẾT KẾ & LẬP KẾ HOẠCH                         ║  │
│  ╠═══════════════════════════════════════════════════════════════════════╣  │
│  ║  /plan                    │  /visualize                               ║  │
│  ║  Lên kế hoạch chi tiết    │  Thiết kế giao diện                       ║  │
│  ╚═══════════════════════════════════════════════════════════════════════╝  │
│                              │                                              │
│                              ▼                                              │
│  ╔═══════════════════════════════════════════════════════════════════════╗  │
│  ║                    💻 VIẾT CODE & CHẠY THỬ                            ║  │
│  ╠═══════════════════════════════════════════════════════════════════════╣  │
│  ║  /code         │  /run          │  /test                              ║  │
│  ║  Viết code     │  Chạy app      │  Kiểm tra                           ║  │
│  ╚═══════════════════════════════════════════════════════════════════════╝  │
│                              │                                              │
│                              ▼                                              │
│  ╔═══════════════════════════════════════════════════════════════════════╗  │
│  ║                    🚀 TRIỂN KHAI & BẢO TRÌ                            ║  │
│  ╠═══════════════════════════════════════════════════════════════════════╣  │
│  ║  /deploy    │  /debug     │  /refactor  │  /audit    │  /rollback    ║  │
│  ║  Đưa lên    │  Sửa lỗi    │  Dọn dẹp    │  Kiểm tra  │  Hoàn tác     ║  │
│  ╚═══════════════════════════════════════════════════════════════════════╝  │
│                              │                                              │
│                              ▼                                              │
│  ╔═══════════════════════════════════════════════════════════════════════╗  │
│  ║                    💾 LƯU TRỮ & CẬP NHẬT                              ║  │
│  ╠═══════════════════════════════════════════════════════════════════════╣  │
│  ║  /save-brain              │  /awf-update                              ║  │
│  ║  Lưu kiến thức            │  Cập nhật AWF                             ║  │
│  ╚═══════════════════════════════════════════════════════════════════════╝  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 📚 3 KỊCH BẢN SỬ DỤNG AWF

---

## 🆕 KỊCH BẢN 1: Tạo App Mới Từ Đầu

> **Tình huống:** Bạn có ý tưởng và muốn làm app từ con số 0.

### Luồng hoạt động:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   BẠN CÓ Ý TƯỞNG                                                            │
│   "Em muốn làm app quản lý tiệm cà phê"                                     │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 1: /brainstorm (Nếu ý tưởng còn mơ hồ)                         │   │
│   │                                                                     │   │
│   │ AI sẽ hỏi:                                                          │   │
│   │ • "App giải quyết vấn đề gì?"                                       │   │
│   │ • "Ai sẽ dùng? Chủ tiệm hay nhân viên?"                             │   │
│   │ • "Có muốn em tìm xem thị trường có app tương tự không?"            │   │
│   │                                                                     │   │
│   │ → Output: BRIEF.md (Tóm tắt ý tưởng)                                │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 2: /init (Tạo dự án)                                           │   │
│   │                                                                     │   │
│   │ AI sẽ hỏi:                                                          │   │
│   │ • "Loại app: Website / Web App / Mobile?"                           │   │
│   │ • "Tên project?"                                                    │   │
│   │                                                                     │   │
│   │ AI TỰ LÀM (bạn không cần biết):                                     │   │
│   │ • Cài đặt công nghệ phù hợp                                         │   │
│   │ • Tạo cấu trúc thư mục                                              │   │
│   │ • Cài đặt Git, ESLint, Prettier                                     │   │
│   │                                                                     │   │
│   │ → Output: Project sẵn sàng để code                                  │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 3: /plan (Lên kế hoạch tính năng)                              │   │
│   │                                                                     │   │
│   │ AI sẽ hỏi:                                                          │   │
│   │ • "Có cần đăng nhập không?"                                         │   │
│   │ • "Quản lý những gì? (Nhân viên, đơn hàng, menu...)"                │   │
│   │ • "Có cần báo cáo doanh thu không?"                                 │   │
│   │                                                                     │   │
│   │ → Output: Thiết kế chi tiết (PRD, Database schema)                  │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 4: /visualize (Thiết kế giao diện)                             │   │
│   │                                                                     │   │
│   │ AI sẽ hỏi:                                                          │   │
│   │ • "Màn hình nào cần làm trước?"                                     │   │
│   │ • "Trên màn hình có những gì?"                                      │   │
│   │ • "Khi click vào thì chuyển đi đâu?"                                │   │
│   │                                                                     │   │
│   │ → Output: File UI code sẵn sàng                                     │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 5: /code (Viết logic)                                          │   │
│   │                                                                     │   │
│   │ AI TỰ LÀM:                                                          │   │
│   │ • Viết code backend (xử lý dữ liệu)                                 │   │
│   │ • Kết nối database                                                  │   │
│   │ • Xử lý đăng nhập, bảo mật                                          │   │
│   │                                                                     │   │
│   │ QUY TẮC VÀNG:                                                       │   │
│   │ • Chỉ làm những gì bạn yêu cầu                                      │   │
│   │ • Không tự ý deploy hay thay đổi lớn                                │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 6: /run → /test (Chạy và kiểm tra)                             │   │
│   │                                                                     │   │
│   │ • /run: Chạy app lên xem thử                                        │   │
│   │ • /test: Kiểm tra xem có lỗi gì không                               │   │
│   │                                                                     │   │
│   │ Nếu có lỗi → /debug để sửa                                          │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 7: /deploy (Đưa lên internet)                                  │   │
│   │                                                                     │   │
│   │ AI TỰ LÀM:                                                          │   │
│   │ • Cấu hình hosting                                                  │   │
│   │ • Thiết lập domain                                                  │   │
│   │ • SEO, Analytics, bảo mật                                           │   │
│   │                                                                     │   │
│   │ → Output: App live trên internet!                                   │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 8: /save-brain (Lưu kiến thức)                                 │   │
│   │                                                                     │   │
│   │ Lưu lại tất cả để mai còn nhớ:                                      │   │
│   │ • Cấu trúc app                                                      │   │
│   │ • Các API đã tạo                                                    │   │
│   │ • Quy tắc nghiệp vụ                                                 │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   🎉 HOÀN THÀNH! App của bạn đã live!                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Tóm tắt luồng:
```
/brainstorm → /init → /plan → /visualize → /code → /run → /test → /deploy → /save-brain
```

---

## 📦 KỊCH BẢN 2: Thêm AWF vào App Có Sẵn

> **Tình huống:** Bạn đã có app đang chạy, muốn dùng AWF để phát triển tiếp.

### Luồng hoạt động:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   BẠN CÓ APP SẴN                                                            │
│   (Đã có code, đang chạy)                                                   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 1: Cài đặt AWF vào project                                     │   │
│   │                                                                     │   │
│   │ Chạy lệnh cài đặt:                                                  │   │
│   │ curl -fsSL https://raw.githubusercontent.com/.../install.sh | bash  │   │
│   │                                                                     │   │
│   │ AWF sẽ tạo file GEMINI.md trong project                             │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 2: /recap (Cho AI hiểu app của bạn)                            │   │
│   │                                                                     │   │
│   │ AI sẽ TỰ ĐỘNG:                                                      │   │
│   │ • Đọc cấu trúc thư mục                                              │   │
│   │ • Phân tích code hiện có                                            │   │
│   │ • Hiểu tech stack đang dùng                                         │   │
│   │ • Xem git history                                                   │   │
│   │                                                                     │   │
│   │ AI sẽ TÓM TẮT:                                                      │   │
│   │ "📋 Em hiểu app của anh là [X], dùng [tech], có [features]..."      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 3: /save-brain (Lưu kiến thức về app)                          │   │
│   │                                                                     │   │
│   │ Quan trọng! Để AI "nhớ" app của bạn:                                │   │
│   │ • Cấu trúc database                                                 │   │
│   │ • Các API endpoints                                                 │   │
│   │ • Quy tắc nghiệp vụ đặc biệt                                        │   │
│   │                                                                     │   │
│   │ → Từ giờ AI sẽ hiểu context của app                                 │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 4: Sẵn sàng! Bắt đầu phát triển                                │   │
│   │                                                                     │   │
│   │ Giờ bạn có thể dùng:                                                │   │
│   │ • /plan - Thêm tính năng mới                                        │   │
│   │ • /debug - Sửa lỗi                                                  │   │
│   │ • /refactor - Dọn dẹp code cũ                                       │   │
│   │ • /audit - Kiểm tra bảo mật, hiệu năng                              │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   🎉 AWF đã sẵn sàng hỗ trợ app của bạn!                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Tóm tắt luồng:
```
Cài AWF → /recap → /save-brain → Sẵn sàng dùng các lệnh khác
```

---

## ➕ KỊCH BẢN 3: Thêm Tính Năng Mới vào App

> **Tình huống:** App đã có, bạn muốn thêm tính năng mới.

### Luồng hoạt động:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   BẠN MUỐN THÊM TÍNH NĂNG                                                   │
│   "Em muốn thêm tính năng báo cáo doanh thu"                                │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 0: /recap (Nếu lâu không làm việc với app)                     │   │
│   │                                                                     │   │
│   │ AI sẽ nhắc lại:                                                     │   │
│   │ • App đang làm gì                                                   │   │
│   │ • Lần cuối làm đến đâu                                              │   │
│   │ • Có việc dở dang không                                             │   │
│   │                                                                     │   │
│   │ (Bỏ qua nếu vừa mới làm việc với app)                               │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 1: /brainstorm HOẶC /plan                                      │   │
│   │                                                                     │   │
│   │ Chọn /brainstorm nếu:                                               │   │
│   │ • Chưa chắc tính năng cần gì                                        │   │
│   │ • Muốn thảo luận nhiều hướng                                        │   │
│   │ • Cần research xem người ta làm thế nào                             │   │
│   │                                                                     │   │
│   │ Chọn /plan nếu:                                                     │   │
│   │ • Đã biết rõ tính năng cần gì                                       │   │
│   │ • Chỉ cần AI thiết kế chi tiết                                      │   │
│   │                                                                     │   │
│   │ AI sẽ hỏi về tính năng và tạo thiết kế                              │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 2: /visualize (Nếu tính năng có giao diện)                     │   │
│   │                                                                     │   │
│   │ AI sẽ hỏi về màn hình:                                              │   │
│   │ • "Màn hình báo cáo hiển thị những gì?"                             │   │
│   │ • "Có biểu đồ không? Loại nào?"                                     │   │
│   │ • "Có nút export PDF không?"                                        │   │
│   │                                                                     │   │
│   │ → Tạo UI cho tính năng mới                                          │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 3: /code (Viết code tính năng)                                 │   │
│   │                                                                     │   │
│   │ AI sẽ:                                                              │   │
│   │ • Viết code cho tính năng mới                                       │   │
│   │ • Kết nối với code cũ                                               │   │
│   │ • Đảm bảo không phá hỏng gì                                         │   │
│   │                                                                     │   │
│   │ QUY TẮC: Thay đổi tối thiểu, không ảnh hưởng code đang chạy tốt     │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 4: /run → /test (Kiểm tra)                                     │   │
│   │                                                                     │   │
│   │ • /run: Chạy app, test tính năng mới                                │   │
│   │ • /test: Kiểm tra tính năng mới VÀ tính năng cũ                     │   │
│   │   (đảm bảo không phá gì)                                            │   │
│   │                                                                     │   │
│   │ Nếu lỗi → /debug                                                    │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 5: /deploy (Cập nhật lên server)                               │   │
│   │                                                                     │   │
│   │ AI sẽ:                                                              │   │
│   │ • Đẩy code mới lên server                                           │   │
│   │ • Không downtime (app vẫn chạy)                                     │   │
│   │ • Backup phòng trường hợp cần rollback                              │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│          │                                                                  │
│          ▼                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ BƯỚC 6: /save-brain (Lưu kiến thức mới)                             │   │
│   │                                                                     │   │
│   │ Cập nhật kiến thức về app:                                          │   │
│   │ • Tính năng mới đã thêm                                             │   │
│   │ • API mới (nếu có)                                                  │   │
│   │ • Quy tắc nghiệp vụ mới                                             │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   🎉 TÍNH NĂNG MỚI ĐÃ LIVE!                                                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Tóm tắt luồng:
```
(/recap) → /brainstorm hoặc /plan → /visualize → /code → /run → /test → /deploy → /save-brain
```

---

## 🆘 KHI GẶP KHÓ KHĂN

### Không biết làm gì tiếp?
```
Gõ: /next
→ AI sẽ phân tích và gợi ý bước tiếp theo
```

### Bị lỗi?
```
Gõ: /debug
→ AI sẽ tìm và sửa lỗi
```

### Muốn quay lại phiên bản cũ?
```
Gõ: /rollback
→ AI sẽ giúp khôi phục
```

### Kiểm tra app có vấn đề gì không?
```
Gõ: /audit
→ AI kiểm tra bảo mật, hiệu năng, code quality
```

---

## 📊 BẢNG TÓM TẮT TẤT CẢ LỆNH

| Lệnh | Khi nào dùng | Output |
|------|--------------|--------|
| `/brainstorm` | Có ý tưởng mơ hồ, cần thảo luận | BRIEF.md |
| `/init` | Tạo project mới | Project sẵn sàng |
| `/recap` | Quên đang làm gì, quay lại sau lâu | Tóm tắt context |
| `/next` | Không biết bước tiếp theo | Gợi ý cụ thể |
| `/plan` | Thiết kế tính năng | PRD, Schema |
| `/visualize` | Thiết kế giao diện | UI code |
| `/code` | Viết logic, backend | Code hoàn chỉnh |
| `/run` | Chạy thử app | App running |
| `/test` | Kiểm tra có lỗi không | Test results |
| `/debug` | Sửa lỗi | Bug fixed |
| `/deploy` | Đưa lên internet | App live |
| `/refactor` | Dọn dẹp code | Code sạch hơn |
| `/audit` | Kiểm tra sức khỏe app | Báo cáo |
| `/rollback` | Quay về phiên bản cũ | Khôi phục |
| `/save-brain` | Lưu kiến thức cuối ngày | Knowledge saved |
| `/awf-update` | Cập nhật AWF | AWF mới nhất |

---

## 💡 MẸO SỬ DỤNG

1. **Mỗi sáng:** `/recap` để nhớ lại
2. **Cuối ngày:** `/save-brain` để mai không quên
3. **Khi stuck:** `/next` để được gợi ý
4. **Trước release:** `/audit` + `/test`
5. **Nói tự nhiên:** AI sẽ hỏi lại nếu chưa hiểu

---

*AWF - Antigravity Workflow Framework*
*Your ideas, our engineering.*